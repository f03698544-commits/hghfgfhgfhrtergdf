function check() {
  let x = document.getElementById("a").value.toLowerCase();

  if (x === "время") {
    document.getElementById("r").innerText = "Правильно!";
    document.getElementById("s").play();
  } else {
    document.getElementById("r").innerText = "Неправильно";
  }
}
